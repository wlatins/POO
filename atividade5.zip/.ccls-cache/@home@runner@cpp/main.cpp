#include <iostream>
#include <string>

class Funcionario{
  public:
  Funcionario(float _beneficio = 0.1, float _imp = 0.25){
    beneficio = _beneficio;
    imp = _imp;
  };
  ~Funcionario(){};

  void setsal(float _sal) {
    sal = _sal;
  };
  void setnome(std::string _nome) {
    nome = _nome;
  };
  void setcargo(std::string _cargo) {
    cargo = _cargo;
  };

  float saliquido() {
    return (sal + (sal * beneficio)) - (sal * imp);
  };

  private:
  std::string nome, cargo;
  float sal, beneficio, imp;
};

int main() {
  Funcionario funcionario;
  std::string nomef, cargof;
  float salario;
  std::cout << "Qual o seu nome? "; std::cin >> nomef;
  std::cout << "Qual o seu cargo? "; std::cin >> cargof;
  std::cout << "Qual o seu salário? "; std::cin >> salario;

  funcionario.setnome(nomef);
  funcionario.setcargo(cargof);
  funcionario.setsal(salario);

  std::cout << "Seu salário líquido é " << funcionario.saliquido();
}